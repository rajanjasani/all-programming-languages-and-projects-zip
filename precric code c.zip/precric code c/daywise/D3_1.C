#include<stdio.h>
#include<conio.h>
void main(){
	clrscr();
	printf("\n name:harsh");
	printf("\n address:surat");
	printf("\n mobile:8965234569");
	printf("\n email:harsh12@gmail.com");
	getch();
}