#include<stdio.h>
#include<conio.h>
void arm(int);
void krish(int);
void main(){
	int ch,n,n1;
	clrscr();
	printf("\n1. for armstrong \n2. for krishnmurthi");
	do{
		printf("\nEnter Choice:");
		scanf("%d",&ch);

		switch(ch){
			case 1:
				printf("\nEnter Number:");
				scanf("%d",&n);
				arm(n);
				break;
			case 2:
				printf("\nEnter Number:");
				scanf("%d",&n1);
				krish(n1);
				break;
			case 3:
				exit(0);
			default:
				printf("invalid");
		}
	}
	while(1);
}
void arm(int a){
	int i,sum=0,rem=1,temp;
	temp=a;
	while(temp>0){
		rem=temp%10;
		sum=sum+(rem*rem*rem);
		temp=temp/10;
	}
	if(sum==a){
		printf("\n armstrong");
	}
	else{
		printf("\n not armstrong");
	}

}
void krish(int b){
	int i,sum=0,rem=0,temp,ans=0;
	temp=b;
	while(temp>0){
		rem=temp%10;
		sum=1;
		for(i=rem;i>=1;i--){
			sum=sum*i;
		}
		temp=temp/10;
		ans+=sum;
	}
	if(ans==b){
		printf("krishnmurthi");
	}
	else{
		printf("not krishnmurthi");
	}
}