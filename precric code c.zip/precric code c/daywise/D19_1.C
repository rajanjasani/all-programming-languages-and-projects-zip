#include<stdio.h>
#include<conio.h>
void even(int);
void odd(int);
void main(){
	int n;
	clrscr();
	printf("\nEnter Number:");
	scanf("%d",&n);
	even(n);
	odd(n);
	getch();
}
void even(int a){
	int i=1,sum=0;
	while(i<=a){
		if(i%2==0){
			sum=sum+i;
		}
		i++;
	}
	printf("\nsum of even is %d",sum);
}
void odd(int b){
	int i=1,sum=0;
	do{
		if(i%2!=0){
			sum=sum+i;
		}
	    i++;
	}
	while(i<=b);
	printf("\nsum of odd is %d",sum);
}