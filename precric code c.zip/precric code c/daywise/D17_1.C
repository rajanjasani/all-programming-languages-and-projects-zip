#include<stdio.h>
#include<conio.h>
void gross(int,int);
void main(){
	int basic,level;
	clrscr();
	printf("\nEnter basic:");
	scanf("%d",&basic);
	printf("\nEnter level:");
	scanf("%d",&level);
	gross(basic,level);
	getch();
}
void gross(int a,int b){
	float hra,tax,perk,gross,net;
	if(b==1 && a>=6000){
		perk=1000+500;
	}
	else if(b==2 && a>=4000 && a<6000){
		perk=750+200;
	}
	else if(b==3 && a>=2000 && a<4000){
		perk=500+100;
	}
	else if(b==4 && a>=1000){
		perk=250;
	}
	else{
		perk=0;
	}
	hra=a*.1;
	gross=a+hra+perk;
	if(gross<2000){
		tax=0;
	}
	else if(gross>2000 && gross<4000){
		tax=gross*.03;
	}
	else if(gross>4000 && gross<5000){
		tax=gross*.05;
	}
	else if(gross>=5000){
		tax=gross*.08;
	}
	else{
		tax=0;
	}
	net=gross-tax;
	printf("\nperks is %f",perk);
	printf("\nhra is %f",hra);
	printf("\ntax is %f",tax);
	printf("\ngross is %f",gross);
	printf("\nnet is %f",net);
}