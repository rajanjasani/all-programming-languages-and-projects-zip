#include<stdio.h>
#include<conio.h>
struct emp{
	int id,sal;
	char name[15];
}e1;
void main(){
	int hra,da,pf,net;
	clrscr();
	printf("\nEnter id:");
	scanf("%d",&e1.id);
	printf("\nEnter Name:");
	scanf("%s",&e1.name);
	printf("\nEnter Salary:");
	scanf("%d",&e1.sal);
	hra=e1.sal*0.10;
	da=e1.sal*0.12;
	pf=e1.sal*0.05;
	net=e1.sal+hra+da-pf;
	printf("\nda is %d",da);
	printf("\nhra is %d",hra);
	printf("\npf is %d",pf);
	printf("\nnet sal is %d",net);
	getch();
}