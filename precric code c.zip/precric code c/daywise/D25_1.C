#include<stdio.h>
#include<conio.h>
void sum(int);
void main(){
	int n;
	clrscr();
	sum(n);
	getch();
}
void sum(int a){
	int i,sum=0;
	while(sum<=50){
		printf("\nEnter Number:");
		scanf("%d",&a);
		sum=sum+a;
		printf("\nsum is %d",sum);
	}
}