#include<stdio.h>
#include<conio.h>
void table(int);
void main(){
	int n;
	clrscr();
	printf("\nEnter Number:");
	scanf("%d",&n);
	table(n);
	getch();
}
void table(int a){
	int i;
	for(i=1;i<=10;i++){
		printf("\n%d * %d = %d",a,i,a*i);
	}
}
