#include<stdio.h>
#include<conio.h>
#define pi 3.14
void cir(int);
void main(){
	int r;
	clrscr();
	printf("\nEnter r:");
	scanf("%d",&r);
	cir(r);
	getch();
}
void cir(int a){
      printf("\ncircumference of circle is %f",2*pi*a);
      printf("\narea of circle is %f",pi*a*a);
}