#include<stdio.h>
#include<conio.h>
void pointer(int,int);
void main(){
	int a,b;
	clrscr();
	printf("\nEnter a:");
	scanf("%d",&a);
	printf("\nEnter b:");
	scanf("%d",&b);
	pointer(a,b);
	getch();
}
void pointer(int c,int d){
	int *p1, *p2;
	p1 = &c;
	p2 = &d;
	printf("\nc is %p",p1);
	printf("\nd is %p",p2);
}