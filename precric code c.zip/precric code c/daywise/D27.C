#include<stdio.h>
#include<conio.h>
int prime(int);
void range(int);
void main(){
	int ch,n,ans,i;
	clrscr();
	printf("\n 1.for check prime \n 2.for prime number between 100 and 200 \n 3. for exit");
	do{
		printf("\nEnter your choice:");
		scanf("%d",&ch);
		switch(ch){
			case 1:
				printf("\nEnter Number:");
				scanf("%d",&n);
				ans=prime(n);
				if(ans==0){
					printf("\n it's not prime");
				}
				else{
					printf("\n it's prime");
				}
				break;
			case 2:
				for(i=100;i<=200;i++){
					ans = prime(i);
					if(ans==1){
						printf("\n%d",i);
					}
				}
				break;
			case 3:
				exit(0);
			default:
				printf("invalid");
		}
	}
	while(1);
}
int prime(int a){
	int i,count=0;
	for(i=1;i<=a;i++){
		if(a%i==0){
			count++;
		}
	}
	if(count==2){
		return 1;
	}
	else{
		return 0;
	}


}