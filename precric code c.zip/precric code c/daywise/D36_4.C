#include<stdio.h>
#include<conio.h>
void main(){
	char str[10],str1[10],str2[10];
	clrscr();
	printf("\nFirst:");
	scanf("%s",&str);
	printf("\nSecond:");
	scanf("%s",&str1);
	//str2=strcmp(str,str1);
	printf("%d",strcmp(str,str1));
	getch();
}