#include<stdio.h>
#include<conio.h>
void alpha(char);
void main(){
	char c;
	clrscr();
	printf("\nEnter Character:");
	scanf("%c",&c);
	alpha(c);
	getch();
}
void alpha(char a){
	if(a=='a'||a=='e'|| a=='i'||a=='o'||a=='u'||a=='A'||a=='E'||a=='I'||a=='O'||a=='U'){
		printf("it's alphabet");
	}
	else{
		printf("it's consonent");
	}
}