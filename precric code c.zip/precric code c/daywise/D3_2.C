#include<stdio.h>
#include<conio.h>
void main(){
	clrscr();
	printf("\n\t\t\t\t name:harsh");
	printf("\n\t\t\t\t address:surat");
	printf("\n\t\t\t\t mobile:8965234569");
	printf("\n\t\t\t\t email:harsh12@gmail.com");
	getch();
}