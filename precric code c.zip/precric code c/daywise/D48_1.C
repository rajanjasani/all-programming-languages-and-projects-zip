#include<stdio.h>
#include<conio.h>
void swap(int,int);
void main(){
	int a,b;
	clrscr();
	printf("\nEnter a:");
	scanf("%d",&a);
	printf("\nEnter b:");
	scanf("%d",&b);
	swap(a,b);
	getch();
}
void swap(int c,int d){
	int *p1,*p2,temp;
	p1=&c;
	p2=&d;
	temp=*p1;
	*p1=*p2;
	*p2=temp;
	printf("\na is %d\nb is %d",c,d);
}