#include<stdio.h>
#include<conio.h>
void swi(int,int,char);
void main(){
	int n1,n2;
	char c;
	clrscr();
	printf("\nEnter operator:");
	scanf("%c",&c);
	printf("\nEnter N1:");
	scanf("%d",&n1);
	printf("\nEnter N2:");
	scanf("%d",&n2);
	swi(n1,n2,c);
	getch();
}
void swi(int a,int b,char d){
	switch(d){
		case '+':
			printf("sum is %d",a+b);
			break;
		case '-':
			printf("sub is %d",a-b);
			break;
		case '*':
			printf("mul is %d",a*b);
			break;
		case '/':
			printf("div is %d",a/b);
			break;
		default:
			printf("invalid");
	}
}