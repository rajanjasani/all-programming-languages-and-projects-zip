#include<stdio.h>
#include<conio.h>
//void minmax(int a[5]);
void main(){
	int min,max,i,a[5];
	clrscr();
	for(i=0;i<5;i++){
		printf("\nEnter Element:");
		scanf("%d",&a[i]);
	}
      //	minmax(a);
      min=a[0];
     // for(i=0;i<5;i++){
		if(min>a[i]){
			printf("\nmin is %d",min);

		}
   //   }
       max=a[0];
     // for(i=0;i<5;i++){
		if(max<a[i]){
			printf("\nmax is %d",max);
		}
     // }
	//printf("\nmin is %d",min);
	//printf("\nmax is %d",max);
	getch();
}