#include<stdio.h>
#include<conio.h>
void main(){
	int a[10],i;
	clrscr();
	for(i=1;i<=10;i++){
		printf("\nEnter Marks for stud : %d :",i);
		scanf("%d",&a[i]);
	}
	for(i=1;i<=10;i++){
		printf("\n%d std marks is %d",i,a[i]);
	}
	getch();
}