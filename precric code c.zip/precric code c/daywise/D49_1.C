#include<stdio.h>
#include<conio.h>
void array(int a[]);
void main(){
	int a[5],i,t;
	clrscr();
	printf("\nEnter t:");
	scanf("%d",&t);
	for(i=0;i<t;i++){
		printf("\nEnter values:");
		scanf("%d",&a[i]);
	}
	array(a);
	getch();
}
void array(int b[5]){
	int i;
	for(i=0;i<5;i++){
		printf("\nvalue is %d",b[i]);
	}
}