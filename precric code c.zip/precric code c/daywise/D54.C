#include<stdio.h>
#include<conio.h>
struct student{
	char name[15],course[15],gender[15];
	int year,sub1,sub2,sub3,total,per;
}s1[5];
void main(){
	int i;
	struct student s1[5];
	clrscr();
	//for(i=0;i<5;i++){
		printf("\nEnter name:");
		scanf("%s",&s1.name);
		printf("\nEnter course:");
		scanf("%s",&s1.course);
		printf("\nEnter gender:");
		scanf("%s",&s1.gender);
		printf("\nEnter sub1:");
		scanf("%d",&s1.sub1);
		printf("\nEnter sub2:");
		scanf("%d",&s1.sub2);
		printf("\nEnter sub3:");
		scanf("%d",&s1.sub3);
	//}
		s1.total=s1.sub1+s1.sub2+s1.sub3;
		s1.per=s1.total/3;
		printf("\ntotal is %d",s1.total);
		printf("\nper is %d",s1.per);

	getch();
}