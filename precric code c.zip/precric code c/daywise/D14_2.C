#include<stdio.h>
#include<conio.h>
void leap(int);
void main(){
	int l;
	clrscr();
	printf("\nEnter year:");
	scanf("%d",&l);
	leap(l);
	getch();
}
void leap(int a){
	if(a%100==0){
		if(a%400==0){
			printf("\nit's leap year");
		}
	}
	if(a%4==0){
		printf("\nit's leap year");
	}
	else{
	     printf("\nit's not leap year");
	}

}