#include<stdio.h>
#include<conio.h>
void main(){
	char name[10][3],search[10];
	int a,i;
	clrscr();
	for(i=0;i<3;i++){
		printf("\nEnter Name:");
		scanf("%s",&name);
	}
	printf("\nSearch :");
	scanf("%s",&search);
	for(i=0;i<3;i++){
		if(strcmp(name[i],search)==0){
		       a=1;
		}
	}
	if(a==1){
		printf("\nFound");
	}
	else{
		printf("\nNot Found");
	}
	getch();
}