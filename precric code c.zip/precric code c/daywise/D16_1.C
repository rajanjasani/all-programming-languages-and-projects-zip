#include<stdio.h>
#include<conio.h>
void day(int);
void main(){
	int d;
	clrscr();
	printf("\nEnter No:");
	scanf("%d",&d);
	day(d);
	getch();
}
void day(int a){
	switch(a){
		case 1:
			printf("monday");
			break;
		case 2:
			printf("tuesday");
			break;
		case 3:
			printf("wednsday");
			break;
		case 4:
			printf("thursday");
			break;
		case 5:
			printf("friday");
			break;
		case 6:
			printf("saturday");
			break;
		case 7:
			printf("sunday");
			break;
		default:
			printf("invalid");
	}
}

