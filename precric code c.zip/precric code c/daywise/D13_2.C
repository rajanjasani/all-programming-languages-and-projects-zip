#include<stdio.h>
#include<conio.h>
void grade(int);
void main(){
	int m;
	clrscr();
	printf("\nEnter Marks:");
	scanf("%d",&m);
	grade(m);
	getch();
}
void grade(int a){
	if(a>=80 && a<=100){
		printf("\nDistinction");
	}
	else if(a>=60 && a<=79){
		printf("\nFirst class");
	}
	else if(a>=35 && a<=59){
		printf("\nSecond class");
	}
	else{
	       printf("\nFail");
	}

}