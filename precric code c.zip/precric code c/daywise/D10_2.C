#include<stdio.h>
#include<conio.h>
void main(){
	int a;
	float b;
	char c;
	double d;
	short e;
	long f;
	clrscr();
	printf("\nint:%d",sizeof(a));
	printf("\nfloat:%d",sizeof(b));
	printf("\nchar:%d",sizeof(c));
	printf("\ndouble:%d",sizeof(d));
	printf("\nshort:%d",sizeof(e));
	printf("\nlong:%d",sizeof(f));
	getch();
}