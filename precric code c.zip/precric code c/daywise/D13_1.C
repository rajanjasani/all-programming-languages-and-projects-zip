#include<stdio.h>
#include<conio.h>
void calc(int,int,char);
void main(){
	int n1,n2;
	char c;
	clrscr();
	printf("\nEnter Operator:");
	scanf("%c",&c);
	printf("\nEnter N1:");
	scanf("%d",&n1);
	printf("\nEnter N2:");
	scanf("%d",&n2);
	calc(n1,n2,c);
	getch();
}
void calc(int a,int b,char d){
	if(d=='+'){
		printf("\nsum is %d",a+b);
	}
	else if(d=='-'){
	      printf("\nsub is %d",a-b);
	}
	else if(d=='*'){
	      printf("\nmul is %d",a*b);
	}
	else if(d=='/'){
	      printf("\ndiv is %d",a/b);
	}
	else{
	       printf("\nrem is %d",a%b);
	}
}