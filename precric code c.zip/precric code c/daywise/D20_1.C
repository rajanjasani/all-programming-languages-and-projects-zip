#include<stdio.h>
#include<conio.h>
void sum(int);
void main(){
	int n;
	clrscr();
	printf("\nEnter Number:");
	scanf("%d",&n);
	sum(n);
	getch();
}
void sum(int a){
	float i,sum=0;
	for(i=1;i<=a;i++){
		sum += (1/(i*i));
	}
	printf("sum is %f",sum);
}