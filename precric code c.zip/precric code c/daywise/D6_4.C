#include<stdio.h>
#include<conio.h>
void check(int);
void main(){
	int d;
	clrscr();
	printf("\nEnter Days:");
	scanf("%d",&d);
	check(d);
	getch();
}
void check(int a){
	printf("\nmonth is %d",a/30);
	printf("\ndays is %d",a%30);
}