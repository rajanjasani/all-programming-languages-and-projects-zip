#include<stdio.h>
#include<conio.h>
int check(int,int);
void main(){
	int l,b,ans;
	clrscr();
	printf("\nEnter l:");
	scanf("%d",&l);
	printf("\nEnter b:");
	scanf("%d",&b);
	ans=check(l,b);
	printf("\narea of traingle is %d",ans);
	getch();
}
int check(int c,int d){
	int tr;
	tr=(c*d)/2;
	return tr;
}