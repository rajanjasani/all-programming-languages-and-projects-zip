#include<stdio.h>
#include<conio.h>
int check(int,int);
void main(){
	int n1,n2,ans;
	clrscr();
	printf("\nEnter n1:");
	scanf("%d",&n1);
	printf("\nEnter n2:");
	scanf("%d",&n2);
	ans=check(n1,n2);
	if(ans==1){
		printf("\n it's equal");
	}
	else{
		printf("\n it's not equal");
	}

	getch();
}
int check(int a,int b){
	if(a==b){
		return 1;
	}
	else{
		return 0;
	}
}