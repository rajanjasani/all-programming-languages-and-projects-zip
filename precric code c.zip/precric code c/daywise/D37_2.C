#include<stdio.h>
#include<conio.h>
void main(){
	char str[10],str1[10];
	clrscr();
	printf("\nEnter First string:");
	scanf("%s",&str);
	printf("\nEnter Second string:");
	scanf("%s",&str1);
	strcat(str1,str);
	printf("\nnew string is %s",str1);
	getch();
}