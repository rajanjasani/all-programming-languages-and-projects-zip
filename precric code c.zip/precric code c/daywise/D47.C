#include<stdio.h>
#include<conio.h>
void plus(int,int);
void main(){
	int a,b;
	clrscr();
	printf("\nEnter a:");
	scanf("%d",&a);
	printf("\nEnter b:");
	scanf("%d",&b);
	plus(a,b);
	getch();
}
void plus(int c,int d){
	int *p1,*p2,total;
	p1=&c;
	p2=&d;
	total=*p1 + *p2;
	printf("\ntotal is %d",total);
}