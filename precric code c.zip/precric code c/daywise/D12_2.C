#include<stdio.h>
#include<conio.h>
void oddeven();
void main(){
	clrscr();
	oddeven();
	getch();
}
void oddeven(){
	int n;
	printf("\nEnter Number:");
	scanf("%d",&n);
	if(n%2==0){
		printf("\nit's even");
	}
	else{
		printf("\nit's odd");
	}
}
