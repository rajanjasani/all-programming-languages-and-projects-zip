#include<stdio.h>
#include<conio.h>
void main(){
	int i,sum=0;
	clrscr();
	for(i=100;i<=200;i++){
		if(i%7==0){
			sum=sum+i;
		}
	}
	printf("\nsum is %d",sum);
	getch();
}