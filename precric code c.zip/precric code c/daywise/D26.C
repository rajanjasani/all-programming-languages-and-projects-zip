#include<stdio.h>
#include<conio.h>
void rev(int);
void pali(int);
void main(){
	int ch,n,n1;
	clrscr();
	printf("\n 1. for reverse \n 2.for palindrom \n 3.for exit");
	do{
		printf("\nEnter choice:");
		scanf("%d",&ch);

		switch(ch){
			case 1:
				printf("\nEnter number:");
				scanf("%d",&n);
				rev(n);
				break;
			case 2:
				printf("\nEnter number:");
				scanf("%d",&n1);
				pali(n1);
				break;
			case 3:
				exit(0);
			default:
				printf("\ninvald");
		}
	}
	while(1);
}
void rev(int b){
     int rem=0,r=0;
	while(b>0){
		rem=b%10;    
		r=r*10+rem;
		b=b/10;
	}
	printf("reverse is %d",r);
}
void pali(int a){
	int sum=0,rem,temp=a;
	while(temp>0){
		rem =temp % 10;
		sum = sum * 10 + rem;
		temp /= 10;
	}
	if(a == sum){
		printf("\nit's palindrom");
	}
	else{
		printf("\nit's not palindrom");
	}
}