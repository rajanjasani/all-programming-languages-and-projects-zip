#include<stdio.h>
#include<conio.h>
void sum(int);
void main(){
	int n;
	clrscr();
	printf("\nEnter number:");
	scanf("%d",&n);
	sum(n);
	getch();
}
void sum(int a){
	int i,s=12,sum=0;
	for(i=1;i<=a;i++){
		printf("\n%d",s);
		sum=sum+s;
		s=s+10;
	}
	printf("\nsum is %d",sum);
}