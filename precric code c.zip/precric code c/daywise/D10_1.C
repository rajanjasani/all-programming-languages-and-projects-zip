#include<stdio.h>
#include<conio.h>
void main(){
	int n1,n2;
	clrscr();
	printf("\nEnter N1:");
	scanf("%d",&n1);
	printf("Enter N2:");
	scanf("%d",&n2);
	printf("\nsum is %d",n1+n2);
	printf("\nsub is %d",n1-n2);
	printf("\nmul is %d",n1*n2);
	printf("\ndiv is %d",n1/n2);
	printf("\nrem is %d",n1%n2);
	getch();
}