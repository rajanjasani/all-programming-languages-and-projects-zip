#include<stdio.h>
#include<conio.h>
void main(){
	clrscr();
	printf("\n 5 * 1 = 5");
	printf("\n 5 * 2 = 10");
	printf("\n 5 * 3 = 15");
	printf("\n 5 * 4 = 20");
	printf("\n 5 * 5 = 25");
	printf("\n 5 * 6 = 30");
	printf("\n 5 * 7 = 35");
	printf("\n 5 * 8 = 40");
	printf("\n 5 * 9 = 45");
	printf("\n 5 * 10 = 50");
	getch();
}
