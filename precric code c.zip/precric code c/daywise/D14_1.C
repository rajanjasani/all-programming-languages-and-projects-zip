#include<stdio.h>
#include<conio.h>
void gross(int);
void main(){
	int basic;
	clrscr();
	printf("\nEnter Basic:");
	scanf("%d",&basic);
	gross(basic);
	getch();
}
void gross(int a){
	float da,hra,pf,gross;
	hra=a*.15;
	pf=a*.12;
	if(a<5000){
		da=a*.3;
	}
	else{
		da=a*.45;
	}
	gross=a+da+hra-pf;
	printf("\nda is %f",da);
	printf("\nhra is %f",hra);
	printf("\npf is %f",pf);
	printf("\ngross salary is %f",gross);
}