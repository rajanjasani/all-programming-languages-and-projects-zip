#include<stdio.h>
#include<conio.h>
void convert(float);
void main(){
	float p;
	clrscr();
	printf("\nEnter paisa:");
	scanf("%f",&p);
	convert(p);
	getch();
}
void convert(float a){
	printf("\nrupee is %f ",a/100);
}