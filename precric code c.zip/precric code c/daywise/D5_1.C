#include<stdio.h>
#include<conio.h>
void check(int,int);
void main(){
	int n1,n2;
	clrscr();
	printf("\n Enter no1:");
	scanf("%d",&n1);
	printf("\n Enter no2:");
	scanf("%d",&n2);
	check(n1,n2);
	getch();
}
void check(int a,int b){
	printf("\nadd is %d",a+b);
	printf("\nsub is %d",a-b);
	printf("\nmul is %d",a*b);
	printf("\ndiv is %d",a/b);
	printf("\nmod is %d",a%b);
}
