#include<stdio.h>
#include<conio.h>
void main(){
	int a[5],i,max,min;
	clrscr();
	for(i=0;i<5;i++){
		printf("\nEnter number:");
		scanf("%d",&a[i]);
	}
	max=a[0];
	for(i=0;i<5;i++){
		if(max<a[i]){
			max = a[i];
		}
	}
	min=a[0];
	for(i=0;i<5;i++){
		if(min>a[i]){
			min = a[i];
		}
	}
	printf("\nmax is %d",max);
	printf("\nmin is %d",min);
	getch();
}