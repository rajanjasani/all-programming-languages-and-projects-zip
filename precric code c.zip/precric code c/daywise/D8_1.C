#include<stdio.h>
#include<conio.h>
void student(int,char[10],int,int,int);
void main(){
	 int rno,s1,s2,s3;
	 char name[10];
	 clrscr();
	 printf("\nEnter RollNo:");
	 scanf("%d",&rno);
	  printf("\nEnter Name:");
	 scanf("%s",&name);
	  printf("\nEnter c:");
	 scanf("%d",&s1);
	  printf("\nEnter php:");
	 scanf("%d",&s2);
	  printf("\nEnter rdbms:");
	 scanf("%d",&s3);
	 student(rno,name,s1,s2,s3);
	 getch();
}
void student(int a,char b[10],int c,int d,int e){
	printf("\nroll no is %d",a);
	printf("\nname is %s",b);
	printf("\nc marks is %d",c);
	printf("\nphp marks is %d",d);
	printf("\nrdbms is %d",e);
}