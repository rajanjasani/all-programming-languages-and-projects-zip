#include<stdio.h>
#include<conio.h>
void main(){
	int i,c=0,t=50;
	clrscr();
	for(i=1;i<=t;i++){
		if(i%2!=0){
			if(c==4){
				c=0;
				printf(" %d ",i);
				printf("\n");
			}
			else{
				c++;
				printf(" %d ",i);
			}
		}
	}
	getch();
}