#include<stdio.h>
#include<conio.h>
void main(){
	int n1,n2;
	clrscr();
	printf("\nEnter No1:");
	scanf("%d",&n1);
	printf("\nEnter No2:");
	scanf("%d",&n2);
	printf("\n add is %d",n1+n2);
	printf("\n sub is %d",n1-n2);
	printf("\n mul is %d",n1*n2);
	printf("\n div is %d",n1/n2);
	printf("\n mod is %d",n1%n2);
	getch();
}