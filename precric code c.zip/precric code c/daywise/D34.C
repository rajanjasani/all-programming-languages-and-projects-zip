#include<stdio.h>
#include<conio.h>
void main(){
	int a[5],i,s,flag=0;
	clrscr();
	for(i=0;i<5;i++){
		printf("\nEnter Number:");
		scanf("%d",&a[i]);
	}
	printf("\nSearch Number:");
	scanf("%d",&s);
	for(i=0;i<5;i++){
		if(a[i]==s){
			flag=1;
		}
	}
	if(flag==1){
		printf("\nFound at index");
	}
	else{
		printf("\nNot found");
	}
	getch();
}