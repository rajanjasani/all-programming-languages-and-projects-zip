#include<stdio.h>
#include<conio.h>
void main(){
	char str[10],str1[10];
	clrscr();
	printf("\nEnter String:");
	scanf("%s",&str);
	strcpy(str1,str);
	printf("copy string is %s",str1);
	getch();
}