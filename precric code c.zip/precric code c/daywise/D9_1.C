#include<stdio.h>
#include<conio.h>
void ascii(char);
void main(){
	char c;
	clrscr();
	printf("\nEnter Character:");
	scanf("%c",&c);
	ascii(c);
	getch();
}
void ascii(char a){
	printf("ascii value of character is %d",a);
}
