#include<stdio.h>
#include<conio.h>
void main(){
       /*	int n1,n2,temp=0;
	clrscr();
	printf("\nEnter n1:");
	scanf("%d",&n1);
	printf("\nEnter n2:");
	scanf("%d",&n2);
	printf("\nn1:%d",n1);
	printf("\nn2:%d",n2);
	temp=n1;
	n1=n2;
	n2=temp;
	printf("\nn1:%d",n1);
	printf("\nn2:%d",n2);
	getch(); */
	int n1,n2;
	clrscr();
	printf("\nEnter n1:");
	scanf("%d",&n1);
	printf("\nEnter n2:");
	scanf("%d",&n2);
	printf("\nn1:%d",n1);
	printf("\nn2:%d",n2);
	n1=n1+n2;
	n2=n1-n2;
	n1=n1-n2;
	printf("\nn1:%d",n1);
	printf("\nn2:%d",n2);
	getch();
}