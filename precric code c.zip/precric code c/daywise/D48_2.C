#include<stdio.h>
#include<conio.h>
void main(){
	char name[15];
	char *p1;
	int len,i,t;
	clrscr();
	printf("\nEnter Name:");
	scanf("%s",&name);
	printf("\nname is %s",name);
	p1=&name;
	len=strlen(*p1);
	printf("len is %d",len);
       /*	for(i=0;i<=len;i++){
		t++;
	}
      while(name[i] != '\0'){
		len++;
		i++;
	}
	printf("\nlen is %d",t);    */
	getch();
}
