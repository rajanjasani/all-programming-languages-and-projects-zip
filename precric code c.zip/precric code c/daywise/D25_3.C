#include<stdio.h>
#include<conio.h>
void main(){
	int i,sum=0,rem=0,n;
	clrscr();
	printf("\nEnter Number:");
	scanf("%d",&n);
	while(n>0){
		rem=n%10;
		sum=sum+rem;
		n=n/10;
	}
	printf("sum is %d",sum);
	getch();
}