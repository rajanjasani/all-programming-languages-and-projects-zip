#include<stdio.h>
#include<conio.h>
int check();
void main(){
	int ans;
	clrscr();
	ans=check();
	if(ans==1){
		printf("\nit's alphabet");
	}
	else{
		printf("\nit's not alphabet");
	}
	getch();
}
int check(){
	char c;
	printf("\nEnter Character:");
	scanf("%c",&c);
	if(c>=65 && c<=122){
		return 1;
	}
	else{
		return 0;
	}
}