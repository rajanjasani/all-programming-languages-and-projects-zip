#include<stdio.h>
#include<conio.h>
void gross(int);
void main(){
	int basic;
	clrscr();
	printf("\nEnter basic:");
	scanf("%d",&basic);
	gross(basic);
	getch();
}
void gross(int a){
     float da,hra,concaye,medical,other,gross;
     da=a*.1;
     hra=a*.08;
     concaye=a*.05;
     medical=a*.1;
     other=a*.05;
     gross=a+da+hra+concaye+medical+other;
     printf("\nbasic salary is %d",a);
     printf("\nda is %f",da);
     printf("\nhra is %f",hra);
     printf("\nconcaye is %f",concaye);
     printf("\nmedical is %f",medical);
     printf("\nother is %f",other);
     printf("\ngross salary is %f",gross);
}