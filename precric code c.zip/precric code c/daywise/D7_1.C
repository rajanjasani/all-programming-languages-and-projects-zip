#include<stdio.h>
#include<conio.h>
void intrest(int,int,int);
void main(){
	int p,t,r;
	clrscr();
	printf("\nEnter p:");
	scanf("%d",&p);
	printf("\nEnter r:");
	scanf("%d",&r);
	printf("\nEnter t:");
	scanf("%d",&t);
	intrest(p,t,r);
	getch();
}
void intrest(int a,int b,int c){
	printf("\nsimple intrest is %d",(a*b*c)/100);
}