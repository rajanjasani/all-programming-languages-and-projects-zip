#include<stdio.h>
#include<conio.h>
void data(int,float,char,double,short,long);
void main(){
	int a=52;
	float b=12.3;
	char c='c';
	double d=35000;
	short e=12;
	long f=40000;
	clrscr();
	data(a,b,c,d,e,f);
	getch();
}
void data(int g,float h,char i,double j,short k,long l){
	printf("\nint:%d",g);
	printf("\nfloat:%f",h);
	printf("\nchar:%c",i);
	printf("\ndouble:%lf",j);
	printf("\nshort:%hd",k);
	printf("\nlong:%ld",l);
}