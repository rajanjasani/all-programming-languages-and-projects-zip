#include<stdio.h>
#include<conio.h>
void main(){
	int a[10],i,sum=0;
	clrscr();
	for(i=1;i<=10;i++){
		printf("\nEnter marks:");
		scanf("%d",&a[i]);
	}
	for(i=1;i<=10;i++){
		sum+=a[i];
	}
	printf("\nsum is %d",sum);
	getch();
}