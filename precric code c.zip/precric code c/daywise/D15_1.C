#include<stdio.h>
#include<conio.h>
void eligible(int,int,int);
void main(){
	int p,c,m;
	clrscr();
	printf("\nEnter Physics marks:");
	scanf("%d",&p);
	printf("\nEnter chemistry marks:");
	scanf("%d",&c);
	printf("\nEnter mathematics marks:");
	scanf("%d",&m);
	eligible(p,c,m);
	getch();
}
void eligible(int a,int b,int d){
	int total=a+b+d;
	if(d>=50 && a>=45 && b>=60 && total>=170 || a+d>=120){
		printf("\nEligible");
	}
	else{
		printf("\nNot Eligible");
	}
}