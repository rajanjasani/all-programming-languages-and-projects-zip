#include<stdio.h>
#include<conio.h>
void main(){
	int sub1[3],sub2[3],total[3],i,stud[3];
	clrscr();
	for(i=0;i<3;i++){
		printf("\nEnter stud:");
		scanf("%d",&stud[i]);
		printf("\nEnter sub1:");
		scanf("%d",&sub1[i]);
		printf("\nEnter sub2:");
		scanf("%d",&sub2[i]);
		total[i]=sub1[i]+sub2[i];
	}
	for(i=0;i<3;i++){
		printf("\nSNO : %d | total is %d",stud[i],total[i]);
	}
	getch();
}