#include<stdio.h>
#include<conio.h>
void perfect(int);
void main(){
	int n;
	clrscr();
	printf("\nEnter Number:");
	scanf("%d",&n);
	perfect(n);
	getch();
}
void perfect(int a){
	int i,sum=0;
	for(i=1;i<a;i++){
		if(a%i==0){
			sum=sum+i;
		}
	}

	if(sum==a){
		printf("it's perfect");
	}
	else{
		printf("it's not perfect");
	}
}