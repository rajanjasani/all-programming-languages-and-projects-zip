#include<stdio.h>
#include<conio.h>
void main(){
	int d[5],i,j,temp;
	clrscr();
	for(i=0;i<5;i++){
		printf("\nEnter No:");
		scanf("%d",&d[i]);
	}
	for(i=0;i<4;i++){
		for(j=0;j<4;j++){
			if(d[j] > d[j+1]){
				temp = d[j];
				d[j] = d[j+1];
				d[j+1] = temp;
			}
		}
	}
	for(i=0;i<5;i++){
		printf("%d\n",d[i]);
	}
	getch();
}