#include<stdio.h>
#include<conio.h>
void number(int);
void main(){
	int n;
	clrscr();
	printf("\nEnter Number:");
	scanf("%d",&n);
	number(n);
	getch();
}
void number(int a){
	int i;
	for(i=1;i<=a;i++){
		printf("\n%d",i);
	}
}