#include<stdio.h>
#include<conio.h>
void main(){
	char name[10];
	int len;
	clrscr();
	printf("\nEnter Name:");
	scanf("%s",&name);
	len=strlen(name);
	printf("\nlength is %d",len);
	getch();
}