#include<stdio.h>
#include<conio.h>
void main(){
	char name[10],rev[10];
	clrscr();
	printf("\nEnter Name:");
	scanf("%s",&name);
       printf("\nnew string is %s", strrev(name));
	getch();
}