#include<stdio.h>
#include<conio.h>
#include<math.h>
void compound(float,float,float);
void main(){
	float p,r,n;
	clrscr();
	printf("\nEnter p:");
	scanf("%f",&p);
	printf("\nEnter r:");
	scanf("%f",&r);
	printf("\nEnter n:");
	scanf("%f",&n);
	compound(p,r,n);
	getch();
}
void compound(float a, float b,float c){
	float ans;
	ans=a*(pow((1+b/100),c));
	printf("\ncompound intrest is %f",ans);
}